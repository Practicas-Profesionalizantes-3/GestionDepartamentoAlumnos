// Obtener los datos del trámite desde sessionStorage
const avisoDetalle = JSON.parse(sessionStorage.getItem('avisoDetalle'));

// Verificar si hay datos disponibles
if (avisoDetalle) {
    const avisoDetalleContainer = document.getElementById('aviso-detalle').querySelector('.card-body');

    // Crear el contenido HTML con los datos del trámite
    avisoDetalleContainer.innerHTML = `
              <h1 class="mb-3">${avisoDetalle.titulo}</h1>
            <img src="${avisoDetalle.imagen}" class="img-aviso">
            <p class="descripcion-completa">${avisoDetalle.descripcion}</p>
            <div class="fecha-descarga-container">
                <?php if (!empty(${avisoDetalle.adjunto})) : ?>
                    <div class="descargar-adjunto">
                        <a href="data:application/pdf;base64,${avisoDetalle.adjunto}" download="${avisoDetalle.titulo}" class="btn btn-primary">Descargar adjunto</a>
                    </div>
                <?php endif; ?>
                <p class="fecha">${avisoDetalle.fecha}</p>
            </div>
    `;
} else {
    document.getElementById('aviso-detalle').innerHTML = '<p>No se encontraron datos del aviso.</p>';
}


